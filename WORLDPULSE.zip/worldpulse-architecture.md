# WORLDPULSE — Global Intelligence Network
## Open-Source Architecture, Roadmap & Technical Specification
**Version 0.1.0-alpha | March 2026**

---

## VISION

WorldPulse is the internet's missing layer: a real-time, open-source global intelligence network that combines verified live event monitoring with human social discourse. It beats Twitter on truth, Reddit on depth, Facebook on reach, and every news aggregator on speed — while remaining fully transparent, community-governed, and open to fork or contribute.

---

## CORE PILLARS

| Pillar | Description |
|---|---|
| **Signal First** | Every post, event, and update is a "signal" — tagged, geolocated, time-stamped, source-attributed |
| **Verification Layer** | Multi-source cross-check on all breaking events. AI-assisted + community fact-check |
| **Open by Default** | MIT licensed, self-hostable, API-first, no dark patterns |
| **Real-Time Everything** | WebSocket-driven live feed, server-sent events for signals, 0-lag map updates |
| **Social + Intelligence** | Users post alongside verified sources. Expert accounts earn trust scores |

---

## SYSTEM ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                     WORLDPULSE PLATFORM                      │
├─────────────────────────────────────────────────────────────┤
│  CLIENT LAYER                                                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────┐  │
│  │  Web App │  │ iOS App  │  │Android   │  │ Open API  │  │
│  │ (Next.js)│  │ (Native) │  │(Native)  │  │  (REST+WS)│  │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └─────┬─────┘  │
│       └──────────────┴──────────────┴──────────────┘       │
│                          │ HTTPS / WSS                       │
├─────────────────────────────────────────────────────────────┤
│  API GATEWAY (Kong / Nginx)                                  │
│  Rate limiting · Auth · Load balancing · TLS termination    │
├─────────────────────────────────────────────────────────────┤
│  SERVICE LAYER (Microservices)                               │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌──────────┐ │
│  │ Feed Svc   │ │Signal Svc  │ │ Social Svc │ │ Auth Svc │ │
│  │(Rust/Actix)│ │(Go)        │ │(Node.js)   │ │(Go)      │ │
│  └────────────┘ └────────────┘ └────────────┘ └──────────┘ │
│  ┌────────────┐ ┌────────────┐ ┌────────────┐ ┌──────────┐ │
│  │ Verify Svc │ │  Map Svc   │ │ Search Svc │ │Notify Svc│ │
│  │(Python/AI) │ │(PostGIS)   │ │(Meilisearch│ │(Go)      │ │
│  └────────────┘ └────────────┘ └────────────┘ └──────────┘ │
├─────────────────────────────────────────────────────────────┤
│  INTELLIGENCE PIPELINE                                       │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  SCRAPER NETWORK (Distributed, 200+ nodes)           │   │
│  │  RSS · Wire services · Gov APIs · Seismic · Weather  │   │
│  │  Social firehose · Academic feeds · Satellite data   │   │
│  └──────────────────────┬──────────────────────────────┘   │
│                          │                                   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  AI VERIFICATION ENGINE                              │   │
│  │  Source cross-check · Bias detection · Fact scoring │   │
│  │  Misinformation flagging · Translation · Summary    │   │
│  └──────────────────────┬──────────────────────────────┘   │
│                          │                                   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  MESSAGE QUEUE (Apache Kafka)                        │   │
│  │  signals.raw · signals.verified · events.breaking   │   │
│  │  social.posts · alerts.critical · market.data       │   │
│  └──────────────────────┬──────────────────────────────┘   │
├─────────────────────────┴───────────────────────────────────┤
│  DATA LAYER                                                  │
│  ┌───────────┐ ┌──────────┐ ┌──────────┐ ┌────────────┐   │
│  │PostgreSQL  │ │  Redis   │ │TimescaleDB│ │ClickHouse  │   │
│  │(primary)  │ │(cache/RT)│ │(time-series│ │(analytics) │   │
│  └───────────┘ └──────────┘ └──────────┘ └────────────┘   │
│  ┌───────────┐ ┌──────────┐                                 │
│  │Meilisearch│ │  S3/R2   │                                 │
│  │(full-text)│ │(media)   │                                 │
│  └───────────┘ └──────────┘                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## INTELLIGENCE PIPELINE — DATA SOURCES

### Tier 1: Wire Services & Official Sources
- AP, Reuters, AFP, Bloomberg, BBC
- Government press offices (scraped + API where available)
- UN, WHO, IAEA, WMO official feeds
- USGS (earthquakes), NOAA (weather/climate), NASA Earthdata
- PHIVOLCS, JMA, EMSC (seismic monitoring)
- DEFCON monitoring via open intelligence aggregators

### Tier 2: Digital Monitoring
- RSS feeds from 10,000+ verified news outlets (all languages)
- Social media firehose sampling (Twitter/X API, Reddit API, Mastodon)
- Reddit community signals (subreddit monitoring for local events)
- Telegram public channels (conflict zones, regional news)
- YouTube live stream monitoring (breaking news channels)
- Google Trends API (public interest signals)

### Tier 3: Specialized Data
- Financial markets (Polygon.io, Yahoo Finance, crypto APIs)
- Flight tracking (OpenSky Network, ADS-B Exchange)
- Maritime tracking (MarineTraffic API)
- Satellite imagery (Sentinel Hub, Planet API - open tier)
- Air quality (OpenAQ, IQAir)
- Disease surveillance (ProMED, HealthMap, WHO GOARN)
- Conflict mapping (ACLED, Uppsala Conflict Data)

### Tier 4: Community Intelligence
- User reports (geolocated, reputation-weighted)
- Expert community posts (verified account holders)
- Citation chains (cross-referencing community findings)

---

## VERIFICATION ENGINE

```
Signal Received
      │
      ▼
┌─────────────────┐
│  Source Check   │  Is this from a known reliable source?
│  (Trust Score)  │  Score: 0.0–1.0 per source domain
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Cross-Source   │  Is this confirmed by 2+ independent sources?
│  Verification   │  Time window: 5 min for breaking, 30 min for events
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  AI Fact Layer  │  Contradiction detection, claim extraction,
│                 │  bias scoring, geolocation validation
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Community Flag │  Expert accounts can flag/escalate/correct
│  System         │  Weighted by reputation score
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Reliability    │  Final score (1–5 dots shown in UI)
│  Score Output   │  Displayed with every piece of content
└─────────────────┘
```

**Reliability Score Breakdown:**
- ⬤⬤⬤⬤⬤ (5/5): 3+ major wire services, official source, AI-verified
- ⬤⬤⬤⬤◐ (4.5/5): 2 wire services + community corroboration
- ⬤⬤⬤⬤○ (4/5): 1 wire service + 2 regional verified sources
- ⬤⬤⬤○○ (3/5): Single major source, unverified
- ⬤⬤○○○ (2/5): Community report, unverified
- ⬤○○○○ (1/5): Unverified, flagged as rumor

---

## TECH STACK

### Frontend
```
Framework:     Next.js 15 (App Router)
Language:      TypeScript
Styling:       Tailwind CSS + CSS Variables
Real-time:     Socket.io client + Server-Sent Events
Maps:          MapLibre GL JS (open-source, self-hostable)
Charts:        Observable Plot / D3.js
State:         Zustand + React Query (TanStack)
Auth UI:       Custom + OAuth2
PWA:           next-pwa (offline support)
```

### Backend Services
```
Feed Service:      Rust (Actix-web) — high throughput, low latency
Signal Service:    Go — concurrent scraping pipeline
Social Service:    Node.js (Fastify) — user interactions
Auth Service:      Go + JWT + OAuth2
Verify Service:    Python (FastAPI) + LLM integration
Map Service:       Python (FastAPI) + PostGIS
Search:            Meilisearch (self-hosted)
Notifications:     Go + WebPush + FCM/APNs
```

### Data
```
Primary DB:        PostgreSQL 16 + PostGIS (geospatial)
Cache:             Redis 7 (feed cache, sessions, rate limiting)
Time Series:       TimescaleDB (signals history, market data)
Analytics:         ClickHouse (usage metrics, trend analysis)
Search Index:      Meilisearch
Media Storage:     Cloudflare R2 / self-hosted MinIO
CDN:               Cloudflare (global)
```

### Message Queue & Streaming
```
Queue:             Apache Kafka (signal pipeline)
Stream Processing: Apache Flink (real-time aggregation)
Pub/Sub:           Redis Pub/Sub (live feed WebSocket fan-out)
```

### Infrastructure
```
Container:         Docker + Kubernetes (K3s for self-hosted)
CI/CD:             GitHub Actions
IaC:               Terraform + Helm
Monitoring:        Prometheus + Grafana
Logging:           Loki + Grafana
Uptime:            99.9%+ target (multi-region active-active)
```

---

## SOCIAL FEATURES

### Content Types
1. **Signal Post** — Short update (500 chars) with source tag, geolocation optional
2. **Thread** — Long-form multi-post analysis
3. **Community Report** — Geolocated user reports with photo/video
4. **Signal Boost** — Re-broadcast with optional commentary (like retweet)
5. **Deep Dive** — Long-form article (like Substack, built in)
6. **Poll** — Community opinion with real-time results
7. **Event Room** — Live discussion thread anchored to a breaking event

### Trust & Reputation System
```
Account Types:
  🌐 Verified Journalist    — Press credentials verified
  🏛️  Official Source       — Government/NGO/Institution
  🔬 Domain Expert          — Academic/professional verification
  ⚡ Power User             — Community trust score > 0.85
  👤 Community Member       — Standard account
  🤖 AI Digest              — Platform AI synthesis account

Trust Score = f(
  accuracy_history,
  peer_ratings,
  source_quality,
  time_on_platform,
  correction_acceptance,
  verified_credentials
)
```

### Governance
- Community moderators elected by region + topic
- Transparent moderation log (all actions public)
- Appeals process with independent review panel
- Open moderation playbook on GitHub
- No shadow banning — all restrictions visible to user

---

## OPEN SOURCE STRUCTURE

```
worldpulse/
├── apps/
│   ├── web/              # Next.js frontend
│   ├── api-feed/         # Rust feed service
│   ├── api-signal/       # Go signal pipeline
│   ├── api-social/       # Node.js social service
│   ├── api-verify/       # Python AI verification
│   └── api-auth/         # Go auth service
├── packages/
│   ├── ui/               # Shared component library
│   ├── types/            # Shared TypeScript types
│   ├── scraper-sdk/      # Scraper node toolkit
│   └── verify-sdk/       # Verification utilities
├── infrastructure/
│   ├── k8s/              # Kubernetes manifests
│   ├── terraform/        # Cloud infrastructure
│   └── docker/           # Docker compose (local dev)
├── docs/
│   ├── architecture.md
│   ├── api.md
│   ├── contributing.md
│   └── self-hosting.md
└── README.md
```

**License:** MIT  
**Contributing:** Open PRs, RFC process for major features  
**Self-hosting:** Single `docker compose up` for full stack  
**API:** Fully public REST + WebSocket API with generous free tier  

---

## ROADMAP

### Phase 1: Foundation (Months 1–3)
- [ ] Core feed with real-time WebSocket updates
- [ ] Signal pipeline: RSS + 50 wire service feeds
- [ ] Basic social features: post, reply, boost, follow
- [ ] World map with live event pins (MapLibre)
- [ ] Source verification engine (rule-based + LLM)
- [ ] User auth (email + OAuth: Google, GitHub, Apple)
- [ ] Mobile-responsive web app
- [ ] Public REST API v1
- [ ] GitHub open source launch
- [ ] Self-hosting documentation

### Phase 2: Intelligence (Months 4–6)
- [ ] Expand to 500+ data sources across all languages
- [ ] AI Digest: automated event summaries every 30 min
- [ ] Reliability scoring visible on all content
- [ ] Expert verification program launch
- [ ] Full-text search across all signals
- [ ] Communities (topic-based subreddits equivalent)
- [ ] Notification system (push, email, SMS)
- [ ] Scraper SDK for community contributions
- [ ] Translation layer (auto-translate to 50 languages)

### Phase 3: Scale (Months 7–12)
- [ ] Native iOS + Android apps
- [ ] Market data integration (live financial signals)
- [ ] Conflict zone monitoring (ACLED integration)
- [ ] Disease outbreak surveillance (WHO/ProMED)
- [ ] Satellite imagery events
- [ ] Election monitoring module
- [ ] Environmental monitoring (real-time pollution, climate)
- [ ] Community governance system launch
- [ ] Federated architecture option (ActivityPub support)
- [ ] WorldPulse API marketplace

### Phase 4: Ecosystem (Year 2)
- [ ] WorldPulse for Newsrooms (B2B tier)
- [ ] Academic data access program
- [ ] Government crisis coordination integration
- [ ] Developer platform + plugin system
- [ ] Decentralized node network
- [ ] WorldPulse Foundation (non-profit governance)

---

## BUSINESS MODEL (Open Source First)

```
Revenue Streams:
  Free Tier         → Full platform, unlimited signals, API 1K req/day
  Pro ($8/mo)       → Advanced filters, unlimited API, export, no ads
  Teams ($24/mo)    → Collaboration, shared dashboards, priority alerts
  Newsroom API      → Enterprise data access, custom integrations
  Self-hosted       → Free forever (MIT license)

No ads on platform.
No selling user data.
No algorithmic manipulation.
Revenue sustains infrastructure + core team.
Governance by community foundation (Year 2).
```

---

## COMPETITIVE DIFFERENTIATION

| Feature | WorldPulse | Twitter/X | Reddit | World-Monitor |
|---|---|---|---|---|
| Open Source | ✅ Full | ❌ | ❌ | ❌ |
| Source Verification | ✅ AI+Human | ⚠️ Labels | ❌ | ⚠️ |
| Real-time Events | ✅ Live | ✅ | ⚠️ | ✅ |
| Social Discussion | ✅ | ✅ | ✅ | ❌ |
| Expert Trust Scores | ✅ | ⚠️ | ⚠️ | ❌ |
| Self-Hostable | ✅ | ❌ | ❌ | ❌ |
| Global Map View | ✅ | ❌ | ❌ | ✅ |
| No Algorithmic Feed | ✅ Choice | ❌ | ⚠️ | N/A |
| Public API | ✅ Free | ⚠️ $$ | ⚠️ | ❌ |
| Misinformation Block | ✅ Active | ⚠️ | ⚠️ | ❌ |
| All Languages | ✅ 50+ | ✅ | ⚠️ | ❌ |

---

## LAUNCH STRATEGY

1. **GitHub First** — Launch repo before product. Build community of contributors.
2. **Developer Beta** — API-first launch to journalists, developers, researchers.
3. **Show Don't Tell** — Live during a major global event (election, natural disaster).
4. **Newsroom Partnerships** — Partner with 3–5 independent news orgs for early validation.
5. **Academic Program** — Free access for universities doing conflict/climate research.
6. **Self-Host Community** — Support people running their own instances.

---

*WorldPulse is built by the community, for the world.*  
*Every line of code, every decision, every dollar — transparent.*
